# Instant-Chat-With-Doctors-Bajaj-Hackrx-2.0
Best Prototype Award in Bajaj Hackrx 2.0

Web based chat application that enables instant chatting and video calling with the doctors available. 
